//package com.codewithdurgesh.blog.services.impl;
//
////import java.util.List;
////import java.util.Optional;
////import java.util.stream.Collectors;
////
////import org.modelmapper.ModelMapper;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.security.crypto.password.PasswordEncoder;
////import org.springframework.stereotype.Service;
////
////import com.codewithdurgesh.blog.exceptions.*;
////import com.codewithdurgesh.blog.payloads.UserDto;
////import com.codewithdurgesh.blog.services.UserService;
////import com.codewithdurgesh.blog.repositories.*;
////import com.codewithdurgesh.blog.config.AppConstants;
////import com.codewithdurgesh.blog.entities.*;
//////
//////@Service
//////public class UserServiceImpl implements UserService {
//////	
//////	@Autowired
//////    private UserRepository userRepository;
//////
//////	@Autowired
//////	private UserRepo userRepo;
//////
//////	@Autowired
//////	private ModelMapper modelMapper;
//////
//////	@Autowired
//////	private PasswordEncoder passwordEncoder;
//////
//////	@Autowired
//////	private RoleRepo roleRepo;
//////	
//////	
//////	
//////	public void storeUsernameAndPassword(String username, String password, String otp) {
//////        UserEntity userEntity = new UserEntity();
//////        userEntity.setUsername(username);
//////        userEntity.setPassword(password);
//////        userEntity.setOtp(otp);
//////        userRepository.save(userEntity);
//////    }
//////
//////    public Optional<UserEntity> findByUsername(String username) {
//////        return userRepository.findByUsername(username);
//////    }
//////
//////    public boolean validateOtp(String username, String otp) {
//////        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
//////        if (userEntityOpt.isPresent()) {
//////            UserEntity userEntity = userEntityOpt.get();
//////            return userEntity.getOtp().equals(otp);
//////        }
//////        return false;
//////    }
//////	
//////	
//////	
//////	
//////
//////	@Override
//////	public UserDto createUser(UserDto userDto) {
//////		User user = this.dtoToUser(userDto);
//////		User savedUser = this.userRepo.save(user);
//////		return this.userToDto(savedUser);
//////	}
//////
//////	@Override
//////	public UserDto updateUser(UserDto userDto, Integer userId) {
//////
//////		User user = this.userRepo.findById(userId)
//////				.orElseThrow(() -> new ResourceNotFoundException("User", " Id ", userId));
//////
//////		user.setName(userDto.getName());
//////		user.setEmail(userDto.getEmail());
//////		user.setPassword(userDto.getPassword());
//////		user.setAbout(userDto.getAbout());
//////
//////		User updatedUser = this.userRepo.save(user);
//////		UserDto userDto1 = this.userToDto(updatedUser);
//////		return userDto1;
//////	}
//////
//////	@Override
//////	public UserDto getUserById(Integer userId) {
//////
//////		User user = this.userRepo.findById(userId)
//////				.orElseThrow(() -> new ResourceNotFoundException("User", " Id ", userId));
//////
//////		return this.userToDto(user);
//////	}
//////
//////	@Override
//////	public List<UserDto> getAllUsers() {
//////
//////		List<User> users = this.userRepo.findAll();
//////		List<UserDto> userDtos = users.stream().map(user -> this.userToDto(user)).collect(Collectors.toList());
//////
//////		return userDtos;
//////	}
//////
//////	@Override
//////	public void deleteUser(Integer userId) {
//////		User user = this.userRepo.findById(userId)
//////				.orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
//////		this.userRepo.delete(user);
//////
//////	}
//////
//////	public User dtoToUser(UserDto userDto) {
//////		User user = this.modelMapper.map(userDto, User.class);
//////
//////		// user.setId(userDto.getId());
//////		// user.setName(userDto.getName());
//////		// user.setEmail(userDto.getEmail());
//////		// user.setAbout(userDto.getAbout());
//////		// user.setPassword(userDto.getPassword());
//////		return user;
//////	}
//////
//////	public UserDto userToDto(User user) {
//////		UserDto userDto = this.modelMapper.map(user, UserDto.class);
//////		return userDto;
//////	}
//////
//////	@Override
//////	public UserDto registerNewUser(UserDto userDto) {
//////
//////		User user = this.modelMapper.map(userDto, User.class);
//////
//////		// encoded the password
//////		user.setPassword(this.passwordEncoder.encode(user.getPassword()));
//////
//////		// roles
//////		Role role = this.roleRepo.findById(AppConstants.NORMAL_USER).get();
//////
//////		user.getRoles().add(role);
//////
//////		User newUser = this.userRepo.save(user);
//////
//////		return this.modelMapper.map(newUser, UserDto.class);
//////	}
//////
//////}
////
////
//////import java.util.List;
//////import java.util.Optional;
//////import java.util.stream.Collectors;
//////
//////import org.modelmapper.ModelMapper;
//////import org.springframework.beans.factory.annotation.Autowired;
//////import org.springframework.security.crypto.password.PasswordEncoder;
//////import org.springframework.stereotype.Service;
//////
//////import com.codewithdurgesh.blog.entities.Role;
//////import com.codewithdurgesh.blog.entities.User;
//////import com.codewithdurgesh.blog.entities.UserEntity;
//////import com.codewithdurgesh.blog.exceptions.ResourceNotFoundException;
//////import com.codewithdurgesh.blog.payloads.UserDto;
//////import com.codewithdurgesh.blog.repositories.RoleRepo;
//////import com.codewithdurgesh.blog.repositories.UserRepo;
//////import com.codewithdurgesh.blog.repositories.UserRepository;
//////import com.codewithdurgesh.blog.services.UserService;
//////import com.codewithdurgesh.blog.config.AppConstants;
//////
//////@Service
//////public class UserServiceImpl implements UserService {
//////
//////    @Autowired
//////    private UserRepository userRepository;
//////
//////    @Autowired
//////    private UserRepo userRepo;
//////
//////    @Autowired
//////    private ModelMapper modelMapper;
//////
//////    @Autowired
//////    private PasswordEncoder passwordEncoder;
//////
//////    @Autowired
//////    private RoleRepo roleRepo;
//////
//////    @Override
//////    public void storeUsernameAndPassword(String username, String password, String otp) {
//////        UserEntity userEntity = new UserEntity();
//////        userEntity.setUsername(username);  // Mobile number as username
//////        userEntity.setPassword(password);
//////        userEntity.setOtp(otp);
//////        userRepository.save(userEntity);
//////    }
//////
//////    @Override
//////    public Optional<UserEntity> findByUsername(String username) {
//////        return userRepository.findByUsername(username);
//////    }
//////
//////    @Override
//////    public boolean validateOtp(String username, String otp) {
//////        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
//////        if (userEntityOpt.isPresent()) {
//////            UserEntity userEntity = userEntityOpt.get();
//////            return userEntity.getOtp().equals(otp);
//////        }
//////        return false;
//////    }
//////
//////    @Override
//////    public UserDto createUser(UserDto userDto) {
//////        User user = this.dtoToUser(userDto);
//////        User savedUser = this.userRepo.save(user);
//////        return this.userToDto(savedUser);
//////    }
//////
//////    @Override
//////    public UserDto updateUser(UserDto userDto, Integer userId) {
//////        User user = this.userRepo.findById(userId)
//////                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
//////
//////        user.setName(userDto.getName());
//////        user.setEmail(userDto.getEmail());
//////        user.setPassword(userDto.getPassword());
//////        user.setAbout(userDto.getAbout());
//////
//////        User updatedUser = this.userRepo.save(user);
//////        return this.userToDto(updatedUser);
//////    }
//////
//////    @Override
//////    public UserDto getUserById(Integer userId) {
//////        User user = this.userRepo.findById(userId)
//////                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
//////        return this.userToDto(user);
//////    }
//////
//////    @Override
//////    public List<UserDto> getAllUsers() {
//////        List<User> users = this.userRepo.findAll();
//////        return users.stream().map(this::userToDto).collect(Collectors.toList());
//////    }
//////
//////    @Override
//////    public void deleteUser(Integer userId) {
//////        User user = this.userRepo.findById(userId)
//////                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
//////        this.userRepo.delete(user);
//////    }
//////
//////    @Override
//////    public UserDto registerNewUser(UserDto userDto) {
//////        User user = this.modelMapper.map(userDto, User.class);
//////        user.setPassword(this.passwordEncoder.encode(user.getPassword()));
//////
//////        Role role = this.roleRepo.findById(AppConstants.NORMAL_USER).orElseThrow(() -> 
//////            new ResourceNotFoundException("Role", "Id", AppConstants.NORMAL_USER));
//////
//////        user.getRoles().add(role);
//////
//////        User newUser = this.userRepo.save(user);
//////        return this.modelMapper.map(newUser, UserDto.class);
//////    }
//////
//////    private User dtoToUser(UserDto userDto) {
//////        return this.modelMapper.map(userDto, User.class);
//////    }
//////
//////    private UserDto userToDto(User user) {
//////        return this.modelMapper.map(user, UserDto.class);
//////    }
//////}
////
////
////
////
////
////
////
////import com.codewithdurgesh.blog.entities.UserEntity;
////import com.codewithdurgesh.blog.payloads.UserDto;
////import com.codewithdurgesh.blog.repositories.UserRepository;
////import com.codewithdurgesh.blog.services.UserService;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.stereotype.Service;
////
////import java.util.List;
////import java.util.Optional;
////
////@Service
////public class UserServiceImpl implements UserService {
////
////    @Autowired
////    private UserRepository userRepository;
////
////    @Override
////    public void storeUsernameAndPassword(String username, String password, String otp) {
////        UserEntity userEntity = new UserEntity();
////        userEntity.setUsername(username); // Mobile number
////        userEntity.setPassword(password);
////        userEntity.setOtp(otp);
////        userRepository.save(userEntity);
////    }
////
////    @Override
////    public Optional<UserEntity> findByUsername(String username) {
////        return userRepository.findByUsername(username);
////    }
////
////    @Override
////    public boolean validateOtp(String username, String otp) {
////        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
////        if (userEntityOpt.isPresent()) {
////            UserEntity userEntity = userEntityOpt.get();
////            return userEntity.getOtp().equals(otp);
////        }
////        return false;
////    }
////
////	@Override
////	public UserDto createUser(UserDto userDto) {
////		// TODO Auto-generated method stub
////		return null;
////	}
////
////	@Override
////	public UserDto updateUser(UserDto userDto, Integer userId) {
////		// TODO Auto-generated method stub
////		return null;
////	}
////
////	@Override
////	public UserDto getUserById(Integer userId) {
////		// TODO Auto-generated method stub
////		return null;
////	}
////
////	@Override
////	public List<UserDto> getAllUsers() {
////		// TODO Auto-generated method stub
////		return null;
////	}
////
////	@Override
////	public void deleteUser(Integer userId) {
////		// TODO Auto-generated method stub
////		
////	}
////
////	@Override
////	public UserDto registerNewUser(UserDto userDto) {
////		// TODO Auto-generated method stub
////		return null;
////	}
////
////
////
////
////
////
////}
////
//
//
//
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.web.bind.annotation.RequestBody;
//
//import javax.persistence.EntityNotFoundException;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//// Import your entity and DTO classes
//import com.codewithdurgesh.blog.entities.UserEntity;
//import com.codewithdurgesh.blog.payloads.UserDto;
//import com.codewithdurgesh.blog.repositories.UserRepository;
//import com.codewithdurgesh.blog.services.UserService; // Ensure UserService is correctly imported
//
//// If needed, import the custom exception
//// import com.codewithdurgesh.blog.exceptions.EntityNotFoundException; // If you have a custom exception
//
//
//
//
//@Service
//public class UserServiceImpl implements UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Override
//    public void storeUsernameAndPassword(String username, String password, String otp) {
//        UserEntity userEntity = new UserEntity();
//        userEntity.setUsername(username); // Mobile number
//        userEntity.setPassword(password);
//        userEntity.setOtp(otp);
//        userRepository.save(userEntity);
//    }
//
////    @Override
////    public Optional<UserEntity> findByUsername(String username) {
////        return userRepository.findByUsername(username);
////    }
//    
//    
//    public List<UserEntity> findByUsername(String username) {
//        return userRepository.findByUsername1(username);
//    }
//
////    @Override
////    public boolean validateOtp(String username, String otp) {
////        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
////        if (userEntityOpt.isPresent()) {
////            UserEntity userEntity = userEntityOpt.get();
////            return userEntity.getOtp().equals(otp);
////        }
////        return false;
////    }
//    
//    
////    @Override
////    public boolean validateOtp(String username, String otp) {
////        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
////        if (userEntityOpt.isPresent()) {
////            UserEntity userEntity = userEntityOpt.get();
////            return userEntity.getOtp().equals(otp);
////        }
////        return false;
////    }
//    
//    
//    @Override
//    public boolean validateOtp(String username, String otp) {
//        // Fetch the list of users with the given username
//        List<UserEntity> users = userRepository.findByUsername1(username);
//        
//        if (users.isEmpty()) {
//            return false; // No users found with the given username
//        }
//        
//        if (users.size() > 1) {
//            // Handle the case where multiple users are found with the same username
//            throw new IllegalStateException("Multiple users found with the same username");
//        }
//        
//        // Get the single user (there should be exactly one user)
//        UserEntity userEntity = users.get(0);
//        
//        // Check if the OTP matches
//        return userEntity.getOtp().equals(otp);
//    }
//    
//    
//    
//    
//
//    @Override
//    public UserDto createUser(UserDto userDto) {
//        UserEntity userEntity = new UserEntity();
//        userEntity.setUsername(userDto.getUsername());
//        userEntity.setPassword(userDto.getPassword());
//        userEntity.setOtp(userDto.getOtp());
//        UserEntity savedUser = userRepository.save(userEntity);
//        return convertToDto(savedUser);
//    }
//
//    @Override
//    public UserDto updateUser(UserDto userDto, Long userId) {
//        Optional<UserEntity> userOpt = userRepository.findById(userId);
//        if (userOpt.isPresent()) {
//            UserEntity userEntity = userOpt.get();
//            userEntity.setUsername(userDto.getUsername());
//            userEntity.setPassword(userDto.getPassword());
//            userEntity.setOtp(userDto.getOtp());
//            UserEntity updatedUser = userRepository.save(userEntity);
//            return convertToDto(updatedUser);
//        }
//        throw new EntityNotFoundException("User not found with id: " + userId);
//    }
//
//    @Override
//    public UserDto getUserById(Long userId) {
//        Optional<UserEntity> userOpt = userRepository.findById(userId);
//        if (userOpt.isPresent()) {
//            return convertToDto(userOpt.get());
//        }
//        throw new EntityNotFoundException("User not found with id: " + userId);
//    }
//
//    @Override
//    public List<UserDto> getAllUsers() {
//        List<UserEntity> users = userRepository.findAll();
//        return users.stream().map(this::convertToDto).collect(Collectors.toList());
//    }
//
//    @Override
//    public void deleteUser(Long userId) {
//        if (userRepository.existsById(userId)) {
//            userRepository.deleteById(userId);
//        } else {
//            throw new EntityNotFoundException("User not found with id: " + userId);
//        }
//    }
//
//    @Override
//    public UserDto registerNewUser(UserDto userDto) {
//        // Implement registration logic
//        return createUser(userDto);
//    }
//
//    // Convert UserEntity to UserDto
//    private UserDto convertToDto(UserEntity userEntity) {
//        UserDto userDto = new UserDto();
//        userDto.setId(userEntity.getId());
//        userDto.setUsername(userEntity.getUsername());
//        userDto.setPassword(userEntity.getPassword());
//        userDto.setOtp(userEntity.getOtp());
//        return userDto;
//    }
//
//	@Override
//	public UserDto updateUser(UserDto userDto, Integer userId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public UserDto getUserById(Integer userId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void deleteUser(Integer userId) {
//		// TODO Auto-generated method stub
//		
//	}
//}
//
////
////
////
////

package com.codewithdurgesh.blog.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.codewithdurgesh.blog.entities.UserEntity;
import com.codewithdurgesh.blog.repositories.UserRepository;
import com.codewithdurgesh.blog.security.JwtUtil;
import com.codewithdurgesh.blog.services.UserService;

import java.util.Optional;
import java.util.Random;

//@Service
//public class UserServiceImpl implements UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private PasswordEncoder passwordEncoder;
//
//    @Autowired
//    private JwtUtil jwtUtil;
//
//    @Override
//    public UserEntity storeUsernameAndPassword(String username, String password) {
//        // Generate OTP and encode password
//        String otp = generateOtp();
//        UserEntity user = new UserEntity();
//        user.setUsername(username);
//        user.setPassword(passwordEncoder.encode(password));
//        user.setOtp(otp);
//        return userRepository.save(user);
//    }
//
//    @Override
//    public Optional<UserEntity> findByUsername(String username) {
//        return userRepository.findByUsername(username);
//    }
//
//    @Override
//    public boolean validateOtp(String username, String otp) {
//        Optional<UserEntity> userOptional = userRepository.findByUsername(username);
//        if (userOptional.isPresent()) {
//            UserEntity user = userOptional.get();
//            return user.getOtp().equals(otp);
//        }
//        return false;
//    }
//
//    @Override
//    public String generateJwtToken(String username) {
//        return jwtUtil.generateToken(username);
//    }
//
//    private String generateOtp() {
//        Random random = new Random();
//        int otp = 100000 + random.nextInt(900000); // Generate a 6-digit OTP
//        return String.valueOf(otp);
//    }
//}

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JwtUtil jwtUtil;

	@Override
	public UserEntity storeUsernameAndPassword(String username, String otp) {
		// Generate a random password
		String password = generateRandomPassword();

		UserEntity user = new UserEntity();
		user.setUsername(username);
		user.setPassword(passwordEncoder.encode(password));
		user.setOtp(otp);

		return userRepository.save(user);
	}

	@Override
	public Optional<UserEntity> findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public boolean validateOtp(String username, String otp) {
		Optional<UserEntity> userOptional = userRepository.findByUsername(username);
		if (userOptional.isPresent()) {
			UserEntity user = userOptional.get();
			return user.getOtp().equals(otp);
		}
		return false;
	}

	@Override
	public String generateJwtToken(String username) {
		return jwtUtil.generateToken(username);
	}

	private String generateRandomPassword() {
		// Generate a random password of length 12
		int length = 12;
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
		StringBuilder password = new StringBuilder();
		Random random = new Random();

		for (int i = 0; i < length; i++) {
			int index = random.nextInt(characters.length());
			password.append(characters.charAt(index));
		}

		return password.toString();
	}

	@Override
	public String generateRefreshToken(String username) {
		return jwtUtil.generateRefreshToken(username);
	}


	@Override
    public boolean validateRefreshToken(String refreshToken) {
        if (refreshToken == null || refreshToken.isEmpty()) {
            return false;
        }

        // Extract username from refresh token
        String username = jwtUtil.getUsernameFromToken(refreshToken);

        // Check if the refresh token is valid and not expired
        return jwtUtil.validateToken(refreshToken, username);
    }

    @Override
    public String refreshAccessToken(String refreshToken) {
        if (refreshToken == null || refreshToken.isEmpty()) {
            throw new IllegalArgumentException("Refresh token is required.");
        }

        // Validate the refresh token
        if (!validateRefreshToken(refreshToken)) {
            throw new IllegalArgumentException("Invalid or expired refresh token.");
        }

        // Extract username from refresh token
        String username = jwtUtil.getUsernameFromToken(refreshToken);

        // Generate a new access token
        return generateJwtToken(username);
    }
	

	
}
