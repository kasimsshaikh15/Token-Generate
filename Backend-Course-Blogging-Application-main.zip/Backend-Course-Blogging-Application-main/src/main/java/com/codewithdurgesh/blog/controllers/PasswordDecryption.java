package com.codewithdurgesh.blog.controllers;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordDecryption {

	 public static void main(String[] args) {
	       
	 }
}

