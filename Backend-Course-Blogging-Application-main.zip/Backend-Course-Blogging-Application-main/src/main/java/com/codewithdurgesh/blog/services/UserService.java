package com.codewithdurgesh.blog.services;


//public interface UserService {
//
//	UserDto registerNewUser(UserDto user);
//	
//	
//	UserDto createUser(UserDto user);
//
//	UserDto updateUser(UserDto user, Integer userId);
//
//	UserDto getUserById(Integer userId);
//
//	List<UserDto> getAllUsers();
//
//	void deleteUser(Integer userId);
//
//}



//@Service
//public class UserService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    /**
//     * Store the user's username, password, and OTP in the database.
//     */
//    public void storeUsernameAndPassword(String username, String password, String otp) {
//        UserEntity userEntity = new UserEntity();
//        userEntity.setUsername(username); // Mobile number
//        userEntity.setPassword(password);
//        userEntity.setOtp(otp);
//        userRepository.save(userEntity);
//    }
//
//    /**
//     * Retrieve user by username (mobile number).
//     */
//    public Optional<UserEntity> findByUsername(String username) {
//        return userRepository.findByUsername(username);
//    }
//
//    /**
//     * Validate the OTP for the given username.
//     */
//    public boolean validateOtp(String username, String otp) {
//        Optional<UserEntity> userEntityOpt = userRepository.findByUsername(username);
//        if (userEntityOpt.isPresent()) {
//            UserEntity userEntity = userEntityOpt.get();
//            return userEntity.getOtp().equals(otp);
//        }
//        return false;
//    }
//}





import com.codewithdurgesh.blog.entities.UserEntity;
import com.codewithdurgesh.blog.payloads.UserDto;

import java.util.Optional;
import java.util.List;

public interface UserService {
//
//    // Store the username (mobile number), password, and OTP
//    void storeUsernameAndPassword(String username, String password, String otp);
//
//    // Find a user by username (mobile number)
////    Optional<UserEntity> findByUsername(String username);
//      
//    List<UserEntity> findByUsername(String username); 
//
//    // Validate OTP for a given username (mobile number)
//    boolean validateOtp(String username, String otp);
//
//    // Create a new user
//    UserDto createUser(UserDto userDto);
//
//    // Update an existing user
//    UserDto updateUser(UserDto userDto, Integer userId);
//
//    // Get a user by their ID
//    UserDto getUserById(Integer userId);
//
//    // Get all users
//    List<UserDto> getAllUsers();
//
//    // Delete a user by their ID
//    void deleteUser(Integer userId);
//
//    // Register a new user with additional logic (e.g., encoding password, assigning roles)
//    UserDto registerNewUser(UserDto userDto);
//
//	void deleteUser(Long userId);
//
//	UserDto getUserById(Long userId);
//
//	UserDto updateUser(UserDto userDto, Long userId);
	
	
//	void storeUsernameAndPassword(String username, String password, String otp);
//    boolean validateOtp(String username, String otp);
//    String generateToken(String username);

    
//    UserEntity storeUsernameAndPassword(String username, String password);
//
//    Optional<UserEntity> findByUsername(String username);
//
//    boolean validateOtp(String username, String otp);
//
//    String generateJwtToken(String username);
	
	
	UserEntity storeUsernameAndPassword(String username, String otp);

    Optional<UserEntity> findByUsername(String username);

    boolean validateOtp(String username, String otp);

    String generateJwtToken(String username);
    
    
    
    String generateRefreshToken(String username);
    boolean validateRefreshToken(String refreshToken);
    String refreshAccessToken(String refreshToken);
	
	
}


