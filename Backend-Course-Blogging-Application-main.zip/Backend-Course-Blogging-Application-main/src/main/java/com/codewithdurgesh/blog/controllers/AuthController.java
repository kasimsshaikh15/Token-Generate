package com.codewithdurgesh.blog.controllers;
//
//import java.util.List;
//import java.util.Optional;
//
//import javax.persistence.NonUniqueResultException;
//
//import org.apache.commons.lang3.RandomStringUtils;
//import org.modelmapper.ModelMapper;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.codewithdurgesh.blog.entities.User;
//import com.codewithdurgesh.blog.entities.UserEntity;
//import com.codewithdurgesh.blog.payloads.ApiResponse;
//import com.codewithdurgesh.blog.payloads.JwtAuthRequest;
//import com.codewithdurgesh.blog.payloads.JwtAuthResponse;
//import com.codewithdurgesh.blog.payloads.OtpValidationRequest;
//import com.codewithdurgesh.blog.payloads.UserDto;
//import com.codewithdurgesh.blog.payloads.UserRequest;
//import com.codewithdurgesh.blog.security.JwtTokenHelper;
//import com.codewithdurgesh.blog.services.UserService;
//
////import java.security.Principal;
////import java.util.Map;
////import java.util.Optional;
////import java.util.concurrent.ConcurrentHashMap;
////
////import javax.validation.Valid;
////
////import org.modelmapper.ModelMapper;
////import org.slf4j.Logger;
////import org.slf4j.LoggerFactory;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.http.HttpStatus;
////import org.springframework.http.ResponseEntity;
////import org.springframework.security.authentication.AuthenticationManager;
////import org.springframework.security.authentication.BadCredentialsException;
////import org.springframework.security.authentication.DisabledException;
////import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
////import org.springframework.security.core.userdetails.UserDetails;
////import org.springframework.security.core.userdetails.UserDetailsService;
////import org.springframework.ui.ModelMap;
////import org.springframework.web.bind.annotation.CrossOrigin;
////import org.springframework.web.bind.annotation.GetMapping;
////import org.springframework.web.bind.annotation.PostMapping;
////import org.springframework.web.bind.annotation.RequestBody;
////import org.springframework.web.bind.annotation.RequestMapping;
////import org.springframework.web.bind.annotation.RestController;
////
////import com.codewithdurgesh.blog.entities.User;
////import com.codewithdurgesh.blog.exceptions.ApiException;
////import com.codewithdurgesh.blog.payloads.JwtAuthRequest;
////import com.codewithdurgesh.blog.payloads.JwtAuthResponse;
////import com.codewithdurgesh.blog.payloads.UserDto;
////import com.codewithdurgesh.blog.repositories.UserRepo;
////import com.codewithdurgesh.blog.security.JwtTokenHelper;
////import com.codewithdurgesh.blog.services.UserService;
////
////
////import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
////import org.springframework.security.core.Authentication;
////import org.springframework.security.core.context.SecurityContextHolder;
////import org.springframework.security.core.userdetails.UserDetails;
////import org.apache.commons.lang3.RandomStringUtils;
////
////
////@RestController
////@RequestMapping("/api/v1/auth/")
////public class AuthController {
////
////	@Autowired
////	private JwtTokenHelper jwtTokenHelper;
////
////	@Autowired
////	private UserDetailsService userDetailsService;
////
////	@Autowired
////	private AuthenticationManager authenticationManager;
////
////	@Autowired
////	private UserService userService;
////
//////	@PostMapping("/login")
//////	public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
//////		this.authenticate(request.getUsername(), request.getPassword());
//////		UserDetails userDetails = this.userDetailsService.loadUserByUsername(request.getUsername());
//////		String token = this.jwtTokenHelper.generateToken(userDetails);
//////
//////		JwtAuthResponse response = new JwtAuthResponse();
//////		response.setToken(token);
//////		response.setUser(this.mapper.map((User) userDetails, UserDto.class));
//////		return new ResponseEntity<JwtAuthResponse>(response, HttpStatus.OK);
//////	}
//////
//////	private void authenticate(String username, String password) throws Exception {
//////
//////		UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(username,
//////				password);
//////
//////		try {
//////
//////			this.authenticationManager.authenticate(authenticationToken);
//////
//////		} catch (BadCredentialsException e) {
//////			System.out.println("Invalid Detials !!");
//////			throw new ApiException("Invalid username or password !!");
//////		}
//////
//////	}
////	
////	
////	
//////	@PostMapping("/login")
//////	public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
//////	    // Generate a random password
//////	    String generatedPassword = generateRandomPassword();
//////
//////	    // Assuming user registration is handled elsewhere, 
//////	    // and this is just for authentication.
//////	    this.authenticate(request.getUsername(), generatedPassword);
//////
//////	    UserDetails userDetails = this.userDetailsService.loadUserByUsername(request.getUsername());
//////	    String token = this.jwtTokenHelper.generateToken(userDetails);
//////
//////	    JwtAuthResponse response = new JwtAuthResponse();
//////	    response.setToken(token);
//////	    response.setUser(this.mapper.map((User) userDetails, UserDto.class));
//////	    response.setGeneratedPassword(generatedPassword); // Return generated password if needed
//////	    return new ResponseEntity<>(response, HttpStatus.OK);
//////	}
//////
//////	private String generateRandomPassword() {
//////	    // Generate a random password of length 10
//////	    return RandomStringUtils.randomAlphanumeric(10);
//////	}
//////
//////	private void authenticate(String mobileNumber, String password) throws Exception {
//////	    try {
//////	        Authentication authentication = authenticationManager.authenticate(
//////	                new UsernamePasswordAuthenticationToken(mobileNumber, password)
//////	        );
//////	        SecurityContextHolder.getContext().setAuthentication(authentication);
//////	    } catch (Exception e) {
//////	        throw new Exception("Invalid mobile number or password");
//////	    }
//////	}
////	
////	
//////	@PostMapping("/login")
//////	public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
//////	    String mobileNumber = request.getUsername(); // Use the mobile number as the username
//////	    
//////	    // Generate a random password
//////	    String generatedPassword = generateRandomPassword();
//////
//////	    // Authenticate using the mobile number and generated password
//////	    authenticate(mobileNumber, generatedPassword);
//////
//////	    // Load user details based on the mobile number
//////	    UserDetails userDetails = this.userDetailsService.loadUserByUsername(mobileNumber);
//////
//////	    // Generate the JWT token
//////	    String token = this.jwtTokenHelper.generateToken(userDetails);
//////
//////	    // Prepare the response
//////	    JwtAuthResponse response = new JwtAuthResponse();
//////	    response.setToken(token);
//////	    response.setUser(this.mapper.map((User) userDetails, UserDto.class));
//////	    response.setGeneratedPassword(generatedPassword); // Include the generated password in the response if necessary
//////
//////	    return new ResponseEntity<>(response, HttpStatus.OK);
//////	}
//////
//////	private String generateRandomPassword() {
//////	    // Generate a random alphanumeric password of length 10
//////	    return RandomStringUtils.randomAlphanumeric(10);
//////	}
//////
//////	private void authenticate(String mobileNumber, String password) throws Exception {
//////	    try {
//////	        // Authenticate using the mobile number as the username and the generated password
//////	        Authentication authentication = authenticationManager.authenticate(
//////	                new UsernamePasswordAuthenticationToken(mobileNumber, password)
//////	        );
//////	        SecurityContextHolder.getContext().setAuthentication(authentication);
//////	    } catch (Exception e) {
//////	        throw new Exception("Invalid mobile number or password");
//////	    }
//////	}
////
////	
////private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
////    
////    private Map<String, String> temporaryPasswordStore = new ConcurrentHashMap<>();
////
////    @PostMapping("/login")
////    public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
////        String mobileNumber = request.getUsername(); // Use the mobile number as the username
////        
////        // Generate a random password
////        String generatedPassword = generateRandomPassword();
////        
////        // Store the generated password temporarily
////        temporaryPasswordStore.put(mobileNumber, generatedPassword);
////        logger.debug("Generated password for {}: {}", mobileNumber, generatedPassword);
////
////        // Authenticate using the mobile number and generated password
////        authenticate(mobileNumber, generatedPassword);
////
////        // Load user details based on the mobile number
////        UserDetails userDetails = this.userDetailsService.loadUserByUsername(mobileNumber);
////
////        // Generate the JWT token
////        String token = this.jwtTokenHelper.generateToken(userDetails);
////
////        // Prepare the response
////        JwtAuthResponse response = new JwtAuthResponse();
////        response.setToken(token);
////        response.setUser(this.mapper.map((User) userDetails, UserDto.class));
////        response.setGeneratedPassword(generatedPassword); // Include the generated password in the response if necessary
////
////        return new ResponseEntity<>(response, HttpStatus.OK);
////    }
////
////    private String generateRandomPassword() {
////        // Generate a random alphanumeric password of length 10
////        return RandomStringUtils.randomAlphanumeric(10);
////    }
////
////    private void authenticate(String mobileNumber, String password) throws Exception {
////        String storedPassword = temporaryPasswordStore.get(mobileNumber);
////
////        // Debug log to check the stored password
////        logger.debug("Stored password for {}: {}", mobileNumber, storedPassword);
////
////        if (storedPassword == null || !storedPassword.equals(password)) {
////            throw new Exception("Invalid mobile number or password");
////        }
////
////        try {
////            Authentication authentication = authenticationManager.authenticate(
////                    new UsernamePasswordAuthenticationToken(mobileNumber, storedPassword)
////            );
////            SecurityContextHolder.getContext().setAuthentication(authentication);
////
////            // Optionally, remove the password from the store after successful authentication
////            temporaryPasswordStore.remove(mobileNumber);
////        } catch (Exception e) {
////            throw new Exception("Invalid mobile number or password", e);
////        }
////    }
////	
////
////	// register new user api
////
////	@PostMapping("/register")
////	public ResponseEntity<UserDto> registerUser(@Valid @RequestBody UserDto userDto) {
////		UserDto registeredUser = this.userService.registerNewUser(userDto);
////		return new ResponseEntity<UserDto>(registeredUser, HttpStatus.CREATED);
////	}
////
////	// get loggedin user data
////	@Autowired
////	private UserRepo userRepo;
////	@Autowired
////	private ModelMapper mapper;
////
////	@GetMapping("/current-user/")
////	public ResponseEntity<UserDto> getUser(Principal principal) {
////		User user = this.userRepo.findByEmail(principal.getName()).get();
////		return new ResponseEntity<UserDto>(this.mapper.map(user, UserDto.class), HttpStatus.OK);
////	}
////
////}
//
//
//
//
//@RestController
//@RequestMapping("/api/v1/auth/")
//public class AuthController {
//
//    @Autowired
//    private AuthenticationManager authenticationManager;
//
//    @Autowired
//    private UserService userService;
//
//    @Autowired
//    private JwtTokenHelper jwtTokenHelper;
//
//    @Autowired
//    private UserDetailsService userDetailsService;
//
//    @Autowired
//    private ModelMapper mapper;
//    
//    
//    @PostMapping("/store")
//    public ResponseEntity<String> storeUser(@RequestBody UserRequest request) {
//        userService.storeUsernameAndPassword(request.getUsername(), request.getPassword(), request.getOtp());
//        return ResponseEntity.ok("User stored successfully");
//    }
//    
////    @GetMapping("/{username}")
////    public ResponseEntity<UserEntity> getUserByUsername(@PathVariable String username) {
////        Optional<UserEntity> userEntity = userService.findByUsername(username);
////        return userEntity.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
////    }
//    
//    @GetMapping("/{username}")
//    public UserEntity getUserByUsername(String username) {
//        List<UserEntity> users = userService.findByUsername(username);
//        if (users.isEmpty()) {
//            throw new UsernameNotFoundException("User not found with username: " + username);
//        } else if (users.size() > 1) {
//            // Log or handle the case where there are multiple users with the same username
//            throw new NonUniqueResultException("Multiple users found with username: " + username);
//        }
//        return users.get(0);
//    }
//
//    
//    
//
//    @PostMapping("/login")
//    public ResponseEntity<JwtAuthResponse> createToken(@RequestBody JwtAuthRequest request) throws Exception {
//        String username = request.getUsername(); // Mobile number
//        
//        // Generate a random password and OTP
//        String generatedPassword = generateRandomPassword();
//        String generatedOtp = generateOtp();
//
//        // Store the username, password, and OTP in the database
//        userService.storeUsernameAndPassword(username, generatedPassword, generatedOtp);
//
//        // Authenticate using the username and generated password
//        authenticate(username, generatedPassword);
//
//        // Load user details based on the username
//        UserDetails userDetails = userDetailsService.loadUserByUsername(username);
//
//        // Generate the JWT token
//        String token = jwtTokenHelper.generateToken(userDetails);
//
//        // Prepare the response
//        JwtAuthResponse response = new JwtAuthResponse();
//        response.setToken(token);
//        response.setUser(mapper.map((User) userDetails, UserDto.class));
//        response.setGeneratedPassword(generatedPassword); // Include the generated password in the response if necessary
//
//        return new ResponseEntity<>(response, HttpStatus.OK);
//    }
//
//    private String generateRandomPassword() {
//        return RandomStringUtils.randomAlphanumeric(10);
//    }
//
//    private String generateOtp() {
//        return RandomStringUtils.randomNumeric(6); // Generate a 6-digit numeric OTP
//    }
//
////    private void authenticate(String username, String password) throws Exception {
////        try {
////            Authentication authentication = authenticationManager.authenticate(
////                    new UsernamePasswordAuthenticationToken(username, password)
////            );
////            SecurityContextHolder.getContext().setAuthentication(authentication);
////        } catch (Exception e) {
////            throw new Exception("Invalid mobile number or password");
////        }
////    }
//    
//    
//    
////    private void authenticate(String username, String password) throws Exception {
////        try {
////            // Fetch the stored password for comparison (assuming it's the latest generated one)
////            String storedPassword = userService.findByUsername(username)
////                                               .map(UserEntity::getPassword)
////                                               .orElseThrow(() -> new Exception("User not found"));
////
////            if (!password.equals(storedPassword)) {
////                throw new Exception("Invalid password provided.");
////            }
////
////            // Proceed with authentication
////            Authentication authentication = authenticationManager.authenticate(
////                new UsernamePasswordAuthenticationToken(username, password)
////            );
////            SecurityContextHolder.getContext().setAuthentication(authentication);
////        } catch (Exception e) {
////            throw new Exception("Authentication failed", e);
////        }
////    }
//
//    
//    
//    private void authenticate(String username, String password) throws Exception {
//        try {
//            // Fetch the list of users with the given username
//            List<UserEntity> users = userService.findByUsername(username);
//
//            // Ensure there's exactly one user with the given username
//            if (users.isEmpty()) {
//                throw new Exception("User not found");
//            }
//            if (users.size() > 1) {
//                throw new Exception("Multiple users found with the same username");
//            }
//
//            // Get the user (there should be exactly one user)
//            UserEntity user = users.get(0);
//            String storedPassword = user.getPassword();
//
//            if (!password.equals(storedPassword)) {
//                throw new Exception("Invalid password provided.");
//            }
//
//            // Proceed with authentication
//            Authentication authentication = authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(username, password)
//            );
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//        } catch (Exception e) {
//            throw new Exception("Authentication failed", e);
//        }
//    }
//
//    
//
//    @PostMapping("/validate-otp")
//    public ResponseEntity<?> validateOtp(@RequestBody OtpValidationRequest request) {
//        boolean isValid = userService.validateOtp(request.getUsername(), request.getOtp());
//        if (isValid) {
//            return new ResponseEntity<>(new ApiResponse("OTP validated successfully", true), HttpStatus.OK);
//        } else {
//            return new ResponseEntity<>(new ApiResponse("Invalid OTP", false), HttpStatus.BAD_REQUEST);
//        }
//    }
//}
//
//
//
//







//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.codewithdurgesh.blog.services.UserService;
//
//@RestController
//@RequestMapping("/api/v1/auth")
//public class AuthController {
//
//    @Autowired
//    private UserService userService;
//
////    @PostMapping("/register")
////    public ResponseEntity<String> registerUser(@RequestParam String username, @RequestParam String password) {
////        userService.storeUsernameAndPassword(username, password);
////        return ResponseEntity.ok("User registered successfully.");
////    }
//    
//    
//    
//    
//
//    @PostMapping("/login")
//    public ResponseEntity<String> login(@RequestParam String username, @RequestParam String otp) {
//        if (userService.validateOtp(username, otp)) {
//            String token = userService.generateJwtToken(username);
//            return ResponseEntity.ok("Bearer " + token);
//        }
//        return ResponseEntity.status(401).body("Invalid OTP");
//    }
//}




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.codewithdurgesh.blog.payloads.LoginResponse;
import com.codewithdurgesh.blog.payloads.RefreshAccessTokenResponse;
import com.codewithdurgesh.blog.payloads.RefreshTokenRequest;
import com.codewithdurgesh.blog.payloads.TokenResponse;
import com.codewithdurgesh.blog.services.UserService;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestParam String username, @RequestParam String otp) {
        if (username == null || username.isEmpty() || otp == null || otp.isEmpty()) {
            return ResponseEntity.badRequest().body("Username and OTP are required.");
        }
        userService.storeUsernameAndPassword(username, otp);
        return ResponseEntity.ok("User registered successfully.");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestParam String username, @RequestParam String otp) {
        if (userService.validateOtp(username, otp)) {
            String token = userService.generateJwtToken(username);
//            return ResponseEntity.ok("Bearer " + token);
         // Response including username and token
//            return ResponseEntity.ok(new LoginResponse(username, "Bearer " + token));
            return ResponseEntity.ok(new LoginResponse(username, token));
        }
        return ResponseEntity.status(401).body("Invalid OTP");
    }
    
    
    
//    @PostMapping("/refresh-token")
//    public ResponseEntity<?> refreshToken(@RequestParam String refreshToken) {
//        try {
//            String newAccessToken = userService.refreshAccessToken(refreshToken);
//            return ResponseEntity.ok(new TokenResponse(newAccessToken));
//        } catch (RuntimeException e) {
//            return ResponseEntity.status(401).body("Invalid or expired refresh token");
//        }
//    }
    
    @PostMapping("/refresh-token")
    public ResponseEntity<?> refreshToken(@RequestBody RefreshTokenRequest request) {
        String refreshToken = request.getRefreshToken();

        try {
            // Validate the refresh token
            if (!userService.validateRefreshToken(refreshToken)) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired refresh token.");
            }

            // Generate a new access token
            String newAccessToken = userService.refreshAccessToken(refreshToken);

            // Return the new access token
            return ResponseEntity.ok(new RefreshAccessTokenResponse(newAccessToken));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }
    
    
          
}







