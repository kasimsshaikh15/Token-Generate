package com.codewithdurgesh.blog.payloads;

public class OtpValidationRequest {
	
	private String username; // Mobile number
    private String otp;
    
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
    
    

}
