//package com.codewithdurgesh.blog.services;
//
//import java.time.Instant;
//import java.util.UUID;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.codewithdurgesh.blog.entities.RefreshToken;
//import com.codewithdurgesh.blog.entities.User;
//import com.codewithdurgesh.blog.repositories.RefresTokenRepository;
//import com.codewithdurgesh.blog.repositories.UserRepo;
//
//@Service
//public class RefreshTokenService {
//	
//	public long refreshTokenValidity=5*60*60*10000;
//	
//	@Autowired
//	private RefresTokenRepository refresTokenRepository;
//	
//	@Autowired
//	private UserRepo userRepositry;
//
//	
//	//Builder lombok issue so altrnate handle the createRefreshToken method below 
////	private RefreshToken createRefreshToken(String userName) {
////		RefreshToken refreshToken=RefreshToken.builder().refreshToken(UUID.randomUUID().toString()).expiry(Instant.now().plusMillis(refreshTokenValidity)).user(userRepositry.findByEmail(userName).get()).build();
////		return refreshToken;
////	}
//	
//	
//	private RefreshToken createRefreshToken(String userName) {
//	    String token = UUID.randomUUID().toString();
//	    Instant expiryDate = Instant.now().plusMillis(refreshTokenValidity);
//	    User user = userRepositry.findByEmail(userName).get();
//
//	    RefreshToken refreshToken = new RefreshToken(token, expiryDate);
//	    refreshToken.setUser(user);  // Assuming you have a setUser method in RefreshToken
//
//	    return refreshToken;
//	}
//	
//	private RefreshToken verifyRefreshToken(String refreshToken) {
//		RefreshToken refreshTokenOb = refresTokenRepository.findById(refreshToken).orElseThrow(()->new RuntimeException("Given Token does not exist in db"));
//		if(refreshTokenOb.getExpiry().compareTo(Instant.now())<0) {
//			throw new RuntimeException("Refresh Token Expired !!");
//		}
//    	return refreshTokenOb;
//	}
//	
//	
//
//}
