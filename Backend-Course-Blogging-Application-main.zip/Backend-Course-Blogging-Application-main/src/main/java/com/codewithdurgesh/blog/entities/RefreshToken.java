//package com.codewithdurgesh.blog.entities;
//
//import java.time.Instant;
//
//import javax.persistence.Entity;
//import javax.persistence.Table;
//
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.NoArgsConstructor;
//@Entity
//@Table(name="refresh_tokens")
//public class RefreshToken {
//
//	private String refreshToken;
//	
//	private Instant expiry;
//	
//    private User user; 
//
//	
//     //Builder issue so altrante RefreshToken constructor Factory method below
////	@Builder
////	public RefreshToken(String refreshToken, Instant expiry) {
////		super();
////		this.refreshToken = refreshToken;
////		this.expiry = expiry;
////	}
//	
//	
//	public RefreshToken(String refreshToken, Instant expiry) {
//		super();
//		this.refreshToken = refreshToken;
//		this.expiry = expiry;
//	}
//	
//	 // Factory method
//    public static RefreshToken of(String refreshToken, Instant expiry) {
//        return new RefreshToken(refreshToken, expiry);
//    }
//	
//
//	public String getRefreshToken() {
//		return refreshToken;
//	}
//
//	public void setRefreshToken(String refreshToken) {
//		this.refreshToken = refreshToken;
//	}
//
//	public Instant getExpiry() {
//		return expiry;
//	}
//
//	public void setExpiry(Instant expiry) {
//		this.expiry = expiry;
//	}
//
//	public User getUser() {
//		return user;
//	}
//
//	public void setUser(User user) {
//		this.user = user;
//	}
//
//	
//	
//	
//
////	public RefreshToken() {
////		super();
////		// TODO Auto-generated constructor stub
////	}
//
//		
//	
//}
