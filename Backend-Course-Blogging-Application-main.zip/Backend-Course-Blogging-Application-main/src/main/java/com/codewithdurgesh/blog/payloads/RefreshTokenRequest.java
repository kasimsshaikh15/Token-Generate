package com.codewithdurgesh.blog.payloads;

public class RefreshTokenRequest {


    private String refreshToken;

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public RefreshTokenRequest(String refreshToken) {
		super();
		this.refreshToken = refreshToken;
	}

	public RefreshTokenRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
	
}
